#!/system/bin/sh
set -eu

REMOTE="${1:-/data/local/tmp/js7_rollback}"
PRODUCT="$(getprop ro.product.name)"
DEVICE="$(getprop ro.product.device)"
BUILD="$(getprop ro.build.display.id)"
LOGO_PART=/dev/block/platform/mtk-msdc.0/11120000.msdc0/by-name/logo

if [ "$PRODUCT" != "full_k80_bsp" ] || [ "$DEVICE" != "k80_bsp" ] || [ "$BUILD" != "CMDAZX80-U1_R8010_S6.14" ]; then
    echo "ABORT: wrong device: product=$PRODUCT device=$DEVICE build=$BUILD"
    exit 20
fi
[ "$(id -u)" = "0" ] || { echo "ABORT: root ADB is required"; exit 21; }
[ -b "$LOGO_PART" ] || { echo "ABORT: exact JS7 logo partition was not found"; exit 22; }
[ -f "$REMOTE/build.prop" ] && [ -f "$REMOTE/prop.default" ] && [ -f "$REMOTE/bootanimation.mp4" ] && [ -f "$REMOTE/logo.img" ] || {
    echo "ABORT: incomplete rollback backup"
    exit 23
}
[ "$(wc -c < "$REMOTE/logo.img" | tr -d ' ')" = "8388608" ] || {
    echo "ABORT: rollback logo image is not exactly 8 MiB"
    exit 24
}

restore_setting() {
    namespace="$1"
    key="$2"
    value="$3"
    if [ -z "$value" ] || [ "$value" = "null" ]; then
        settings delete "$namespace" "$key" >/dev/null 2>&1 || true
    else
        settings put "$namespace" "$key" "$value"
    fi
}

cp "$REMOTE/build.prop" /system/build.prop
cp "$REMOTE/prop.default" /system/etc/prop.default
cp "$REMOTE/bootanimation.mp4" /system/media/bootanimation.mp4
if [ -f "$REMOTE/bootlogo.bmp" ]; then cp "$REMOTE/bootlogo.bmp" /system/media/bootlogo.bmp; else rm -f /system/media/bootlogo.bmp; fi
if [ -f "$REMOTE/carplay.ini" ]; then cp "$REMOTE/carplay.ini" /system/etc/carplay.ini; else rm -f /system/etc/carplay.ini; fi
if [ -f "$REMOTE/js7_adb_failsafe.rc" ]; then cp "$REMOTE/js7_adb_failsafe.rc" /system/etc/init/js7_adb_failsafe.rc; else rm -f /system/etc/init/js7_adb_failsafe.rc; fi
if [ -f "$REMOTE/bt_config.conf" ]; then cp "$REMOTE/bt_config.conf" /data/misc/bluedroid/bt_config.conf; fi
if [ -f "$REMOTE/hotspot_before.txt" ] && [ -f "$REMOTE/wifi_identity.jar" ]; then
    old_hotspot="$(sed -n 's/^Hotspot: //p' "$REMOTE/hotspot_before.txt")"
    if [ -n "$old_hotspot" ] && [ "$old_hotspot" != "null" ]; then
        CLASSPATH="$REMOTE/wifi_identity.jar" app_process /system/bin com.js7.tools.SetWifiIdentity "$old_hotspot" || true
    fi
elif [ -f "$REMOTE/softap.conf" ]; then
    cp "$REMOTE/softap.conf" /data/misc/wifi/softap.conf
fi

if [ -f "$REMOTE/settings_before.txt" ]; then
    time_value="$(sed -n 's/^time_12_24=//p' "$REMOTE/settings_before.txt")"
    bt_value="$(sed -n 's/^bluetooth_name=//p' "$REMOTE/settings_before.txt")"
    global_name="$(sed -n 's/^global_device_name=//p' "$REMOTE/settings_before.txt")"
    secure_name="$(sed -n 's/^secure_device_name=//p' "$REMOTE/settings_before.txt")"
    timezone="$(sed -n 's/^timezone=//p' "$REMOTE/settings_before.txt")"
    net_hostname="$(sed -n 's/^net_hostname=//p' "$REMOTE/settings_before.txt")"
    persist_net_hostname="$(sed -n 's/^persist_net_hostname=//p' "$REMOTE/settings_before.txt")"
    adb_enabled="$(sed -n 's/^adb_enabled=//p' "$REMOTE/settings_before.txt")"
    persist_sys_usb_config="$(sed -n 's/^persist_sys_usb_config=//p' "$REMOTE/settings_before.txt")"
    persist_service_adb_enable="$(sed -n 's/^persist_service_adb_enable=//p' "$REMOTE/settings_before.txt")"
    restore_setting system time_12_24 "$time_value"
    restore_setting secure bluetooth_name "$bt_value"
    restore_setting global device_name "$global_name"
    restore_setting secure device_name "$secure_name"
    restore_setting global adb_enabled "$adb_enabled"
    [ -n "$timezone" ] && setprop persist.sys.timezone "$timezone" || true
    setprop net.hostname "$net_hostname" || true
    setprop persist.net.hostname "$persist_net_hostname" || true
    setprop persist.sys.usb.config "$persist_sys_usb_config" || true
    setprop persist.service.adb.enable "$persist_service_adb_enable" || true
fi

chown 0:0 /system/build.prop /system/etc/prop.default /system/media/bootanimation.mp4
chmod 0644 /system/build.prop /system/media/bootanimation.mp4
chmod 0600 /system/etc/prop.default
restorecon -R /system/media /system/etc /data/misc/bluedroid /data/misc/wifi 2>/dev/null || true
dd if="$REMOTE/logo.img" of="$LOGO_PART" bs=1048576 conv=fsync
pm uninstall com.js7.hyundai >/dev/null 2>&1 || true
sync
echo "ROLLBACK COMPLETE"
