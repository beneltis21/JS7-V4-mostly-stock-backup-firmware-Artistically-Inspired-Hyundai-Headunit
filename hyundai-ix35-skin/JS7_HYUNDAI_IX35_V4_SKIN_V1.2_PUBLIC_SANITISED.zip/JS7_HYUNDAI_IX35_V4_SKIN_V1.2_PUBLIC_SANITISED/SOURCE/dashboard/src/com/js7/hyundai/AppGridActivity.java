package com.js7.hyundai;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class AppGridActivity extends Activity {
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        final PackageManager pm=getPackageManager();
        Intent query=new Intent(Intent.ACTION_MAIN);query.addCategory(Intent.CATEGORY_LAUNCHER);
        final List<ResolveInfo> apps=pm.queryIntentActivities(query,0);
        Collections.sort(apps,new Comparator<ResolveInfo>(){@Override public int compare(ResolveInfo a,ResolveInfo b){return a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString());}});
        GridView grid=new GridView(this);grid.setBackgroundColor(Color.rgb(6,17,28));grid.setNumColumns(6);grid.setVerticalSpacing(14);grid.setHorizontalSpacing(10);grid.setPadding(20,20,20,20);grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setAdapter(new BaseAdapter(){
            @Override public int getCount(){return apps.size();}
            @Override public Object getItem(int p){return apps.get(p);}
            @Override public long getItemId(int p){return p;}
            @Override public View getView(int pos,View old,ViewGroup parent){
                LinearLayout box=new LinearLayout(AppGridActivity.this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);box.setPadding(6,8,6,8);
                ImageView icon=new ImageView(AppGridActivity.this);icon.setImageDrawable(apps.get(pos).loadIcon(pm));box.addView(icon,new LinearLayout.LayoutParams(58,58));
                TextView label=new TextView(AppGridActivity.this);label.setText(apps.get(pos).loadLabel(pm));label.setTextColor(Color.rgb(244,248,251));label.setTextSize(14);label.setGravity(Gravity.CENTER);label.setMaxLines(2);box.addView(label,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,48));
                return box;
            }
        });
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener(){@Override public void onItemClick(AdapterView<?> p,View v,int pos,long id){ResolveInfo r=apps.get(pos);Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_LAUNCHER);i.setClassName(r.activityInfo.packageName,r.activityInfo.name);startActivity(i);}});
        setContentView(grid);
    }
}
