package com.js7.hyundai;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.PlaybackState;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.provider.Settings;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import java.util.Date;
import java.util.Locale;

public class HomeActivity extends Activity {
    DashboardView dashboard;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        dashboard = new DashboardView(this);
        setContentView(dashboard);
    }

    @Override protected void onResume() {
        super.onResume();
        if (dashboard != null) dashboard.invalidate();
    }

    @Override protected void onStart() {
        super.onStart();
        if (dashboard != null) dashboard.startListening();
    }

    @Override protected void onStop() {
        if (dashboard != null) dashboard.stopListening();
        super.onStop();
    }

    @Override protected void onDestroy() {
        if (dashboard != null) dashboard.shutdown();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        // A HOME activity remains on the dashboard instead of exiting to an empty task.
    }

    static final class DashboardView extends View {
        static final int BG = Color.rgb(6, 17, 28);
        static final int SURFACE = Color.rgb(12, 27, 41);
        static final int SURFACE2 = Color.rgb(16, 37, 56);
        static final int LINE = Color.rgb(38, 65, 88);
        static final int TEXT = Color.rgb(244, 248, 251);
        static final int MUTED = Color.rgb(147, 169, 186);
        static final int BLUE = Color.rgb(25, 168, 245);

        final Activity activity;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Handler handler = new Handler();
        final Bitmap logo;
        final BroadcastReceiver mediaReceiver;
        boolean listening;
        boolean observedBluetoothConnection;
        float sx = 1f, sy = 1f;

        DashboardView(Activity activity) {
            super(activity);
            this.activity = activity;
            setBackgroundColor(BG);
            logo = BitmapFactory.decodeResource(getResources(), R.drawable.hyundai_header_logo);
            mediaReceiver = new BroadcastReceiver() {
                @Override public void onReceive(Context context, Intent intent) {
                    String action=intent.getAction();
                    if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) observedBluetoothConnection=true;
                    else if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) observedBluetoothConnection=false;
                    else if ("android.bluetooth.avrcp-controller.profile.action.CONNECTION_STATE_CHANGED".equals(action)||
                            "android.bluetooth.a2dp-sink.profile.action.CONNECTION_STATE_CHANGED".equals(action)||
                            BluetoothAdapter.ACTION_CONNECTION_STATE_CHANGED.equals(action)) {
                        int state=intent.getIntExtra(BluetoothProfile.EXTRA_STATE,BluetoothProfile.STATE_DISCONNECTED);
                        observedBluetoothConnection=state==BluetoothProfile.STATE_CONNECTED;
                    }
                    else if (BluetoothAdapter.ACTION_STATE_CHANGED.equals(action) &&
                            intent.getIntExtra(BluetoothAdapter.EXTRA_STATE,BluetoothAdapter.ERROR)!=BluetoothAdapter.STATE_ON) {
                        observedBluetoothConnection=false;
                    } else if ("android.bluetooth.avrcp-controller.profile.action.TRACK_EVENT".equals(action)) {
                        observedBluetoothConnection=true;
                        Parcelable value=intent.getParcelableExtra("android.bluetooth.avrcp-controller.profile.extra.METADATA");
                        if(value instanceof MediaMetadata) NowPlayingStore.update((MediaMetadata)value,true);
                        Parcelable playback=intent.getParcelableExtra("android.bluetooth.avrcp-controller.profile.extra.PLAYBACK");
                        if(playback instanceof PlaybackState)NowPlayingStore.updatePlayback((PlaybackState)playback,true);
                    }
                    invalidate();
                }
            };
            handler.postDelayed(new Runnable() {
                @Override public void run() { invalidate(); handler.postDelayed(this, 3000); }
            }, 3000);
        }

        void startListening() {
            if(listening)return;
            IntentFilter f=new IntentFilter();
            f.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
            f.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
            f.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
            f.addAction(BluetoothAdapter.ACTION_CONNECTION_STATE_CHANGED);
            f.addAction("android.bluetooth.avrcp-controller.profile.action.CONNECTION_STATE_CHANGED");
            f.addAction("android.bluetooth.a2dp-sink.profile.action.CONNECTION_STATE_CHANGED");
            f.addAction("android.bluetooth.avrcp-controller.profile.action.TRACK_EVENT");
            Intent sticky=activity.registerReceiver(mediaReceiver,f);
            if(sticky!=null)mediaReceiver.onReceive(activity,sticky);
            listening=true;
        }

        void stopListening() {
            if(!listening)return;
            try{activity.unregisterReceiver(mediaReceiver);}catch(Exception ignored){}
            listening=false;
        }

        void shutdown(){stopListening();handler.removeCallbacksAndMessages(null);}

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            sx = getWidth() / 1024f;
            sy = getHeight() / 600f;
            canvas.save();
            canvas.scale(sx, sy);
            drawBackground(canvas);
            drawHeader(canvas);
            drawNavigation(canvas);
            drawMedia(canvas);
            drawQuickActions(canvas);
            drawDock(canvas);
            canvas.restore();
        }

        void drawBackground(Canvas c) {
            p.setShader(new LinearGradient(0, 0, 1024, 600, Color.rgb(6,17,28), Color.rgb(8,27,43), Shader.TileMode.CLAMP));
            c.drawRect(0, 0, 1024, 600, p); p.setShader(null);
        }

        void drawHeader(Canvas c) {
            p.setColor(Color.rgb(5,14,23)); c.drawRect(0, 0, 1024, 58, p);
            p.setColor(LINE); c.drawRect(0, 57, 1024, 58, p);
            // Exact-size 65x34 emblem avoids scaling artifacts on the MDPI panel.
            if (logo != null) c.drawBitmap(logo,20,12,p);
            textBold(c, "HYUNDAI", 96, 39, 21, TEXT, Paint.Align.LEFT);
            text(c, bluetoothHeader(), 650, 34, 11, bluetoothConnected()?BLUE:MUTED, Paint.Align.LEFT);
            text(c, wifiHeader(), 765, 34, 11, wifiConnected()?BLUE:MUTED, Paint.Align.LEFT);
            text(c, gpsHeader(), 855, 34, 11, gpsEnabled()?BLUE:MUTED, Paint.Align.LEFT);
            text(c, android.text.format.DateFormat.getTimeFormat(activity).format(new Date()), 996, 38, 21, TEXT, Paint.Align.RIGHT);
        }

        void drawNavigation(Canvas c) {
            round(c, 18, 72, 600, 510, 17, Color.rgb(11,35,49));
            p.setColor(Color.rgb(27,61,76));
            for (int x=230; x<585; x+=30) for (int y=90; y<490; y+=30) c.drawCircle(x,y,1.3f,p);
            text(c, "NAVIGATION", 42, 112, 16, BLUE, Paint.Align.LEFT);
            text(c, "Where to?", 42, 158, 36, TEXT, Paint.Align.LEFT);
            text(c, Launch.navigationName(activity) + " ready", 42, 184, 16, MUTED, Paint.Align.LEFT);
            round(c, 40, 442, 174, 488, 12, BLUE);
            text(c, "OPEN MAP", 107, 471, 14, Color.rgb(3,16,25), Paint.Align.CENTER);
        }

        void drawMedia(Canvas c) {
            round(c, 614, 72, 1006, 305, 17, SURFACE);
            text(c, "BLUETOOTH AUDIO", 636, 105, 11, BLUE, Paint.Align.LEFT);
            NowPlayingStore.Snapshot media=NowPlayingStore.snapshot();
            boolean connected=bluetoothConnected();
            boolean current=media.hasMetadata() && (!media.bluetoothSource || connected);
            String primary=current?media.title:(connected?"Bluetooth connected":(bluetoothEnabled()?"Ready to connect":"Bluetooth off"));
            String secondary=current?media.artist:(connected?"Waiting for track":(bluetoothEnabled()?"No phone connected":"Turn Bluetooth on"));
            text(c, fit(primary,22,236),636,140,22,TEXT,Paint.Align.LEFT);
            text(c, fit(secondary,16,236),636,167,16,MUTED,Paint.Align.LEFT);
            if(current && media.art!=null){
                round(c,884,91,982,189,12,SURFACE2);
                c.save();c.clipRect(886,93,980,187);c.drawBitmap(media.art,null,new RectF(886,93,980,187),p);c.restore();
            }else{
                round(c,918,91,980,153,14,BLUE);
                text(c,"♫",949,133,30,TEXT,Paint.Align.CENTER);
            }
            p.setColor(LINE); c.drawRect(636, 213, 982, 216, p);
            if(current&&media.hasTimeline()){
                long position=media.currentPosition();
                float progress=Math.max(0f,Math.min(1f,position/(float)media.duration));
                p.setColor(BLUE);c.drawRect(636,213,636+346*progress,216,p);
                text(c,time(position),636,205,10,MUTED,Paint.Align.LEFT);
                text(c,time(media.duration),982,205,10,MUTED,Paint.Align.RIGHT);
            }
            circleButton(c, 753, 259, 19, "|◀");
            circleButton(c, 810, 259, 24, current&&media.isPlaying()?"Ⅱ":"▶");
            circleButton(c, 867, 259, 19, "▶|");
        }

        void drawQuickActions(Canvas c) {
            round(c, 614, 319, 1006, 510, 17, SURFACE);
            String[] labels = {"RADIO", "PHONE", "CARPLAY", "ANDROID AUTO", "BT MUSIC"};
            float[][] boxes = {{630,333,742,407},{750,333,862,407},{870,333,990,407},{690,420,826,494},{834,420,970,494}};
            for (int i=0;i<labels.length;i++) {
                float[] b=boxes[i]; round(c,b[0],b[1],b[2],b[3],12,SURFACE2);
                text(c, labels[i], (b[0]+b[2])/2, (b[1]+b[3])/2+5, 11, i==3?MUTED:TEXT, Paint.Align.CENTER);
            }
        }

        boolean bluetoothEnabled(){
            BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();
            return a!=null&&a.isEnabled();
        }

        boolean bluetoothConnected(){
            BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();
            if(a==null||!a.isEnabled())return false;
            if(observedBluetoothConnection)return true;
            // This head unit is the receiving side of the link. Public A2DP (2)
            // describes the source role and can remain disconnected even while a
            // phone is actively connected to the JS7. Query the Android 8 hidden
            // sink/controller/client profile IDs used by the stock RegLink stack.
            int[] profiles={BluetoothProfile.A2DP,BluetoothProfile.HEADSET,11,12,16,17};
            for(int profile:profiles){
                try{if(a.getProfileConnectionState(profile)==BluetoothProfile.STATE_CONNECTED)return true;}
                catch(Exception ignored){}
            }
            // Android 8 has no hidden-API enforcement. Its overall adapter state is
            // the final conservative fallback when the vendor profile IDs differ.
            try{
                java.lang.reflect.Method method=BluetoothAdapter.class.getMethod("getConnectionState");
                Object value=method.invoke(a);
                return value instanceof Integer&&((Integer)value).intValue()==BluetoothProfile.STATE_CONNECTED;
            }catch(Exception ignored){return false;}
        }

        boolean wifiEnabled(){
            try{WifiManager w=(WifiManager)activity.getApplicationContext().getSystemService(Context.WIFI_SERVICE);return w!=null&&w.isWifiEnabled();}
            catch(Exception ignored){return false;}
        }

        boolean wifiConnected(){
            try{ConnectivityManager m=(ConnectivityManager)activity.getSystemService(Context.CONNECTIVITY_SERVICE);NetworkInfo n=m==null?null:m.getActiveNetworkInfo();return n!=null&&n.isConnected()&&n.getType()==ConnectivityManager.TYPE_WIFI;}
            catch(Exception ignored){return false;}
        }

        boolean gpsEnabled(){
            try{int mode=Settings.Secure.getInt(activity.getContentResolver(),Settings.Secure.LOCATION_MODE,Settings.Secure.LOCATION_MODE_OFF);return mode==Settings.Secure.LOCATION_MODE_HIGH_ACCURACY||mode==Settings.Secure.LOCATION_MODE_SENSORS_ONLY;}
            catch(Exception ignored){return false;}
        }

        String bluetoothHeader(){return bluetoothConnected()?"BT CONNECTED":(bluetoothEnabled()?"BT ON":"BT OFF");}
        String wifiHeader(){return wifiConnected()?"WI-FI ON":(wifiEnabled()?"WI-FI READY":"WI-FI OFF");}
        String gpsHeader(){return gpsEnabled()?"GPS ON":"GPS OFF";}

        String time(long milliseconds){long seconds=Math.max(0,milliseconds/1000);return String.format(Locale.US,"%d:%02d",seconds/60,seconds%60);}

        String fit(String value,float size,float maxWidth){
            if(value==null||value.length()==0)return "Unknown track";
            p.setTypeface(android.graphics.Typeface.create("sans",android.graphics.Typeface.NORMAL));p.setTextSize(size*1.10f);
            if(p.measureText(value)<=maxWidth)return value;
            String shortened=value;
            while(shortened.length()>1&&p.measureText(shortened+"…")>maxWidth)shortened=shortened.substring(0,shortened.length()-1);
            return shortened+"…";
        }

        void drawDock(Canvas c) {
            p.setColor(Color.rgb(5,14,23)); c.drawRect(0,524,1024,600,p);
            p.setColor(LINE); c.drawRect(0,524,1024,525,p);
            // The JS7 fascia already provides physical NAVI, BAND/RADIO, MUSIC
            // and BT controls. Keep the software dock focused on the three
            // destinations that do not have dedicated hardware buttons.
            String[] labels={"HOME","APPS","SETTINGS"};
            for(int i=0;i<labels.length;i++) {
                float left=i*(1024f/3f)+10, right=(i+1)*(1024f/3f)-10;
                if(i==0) round(c,left,533,right,592,12,Color.rgb(10,43,64));
                text(c,labels[i],(left+right)/2,572,18,i==0?BLUE:TEXT,Paint.Align.CENTER);
            }
        }

        void circleButton(Canvas c,float x,float y,float r,String label) {
            p.setColor(r>20?BLUE:SURFACE2); c.drawCircle(x,y,r,p);
            text(c,label,x,y+5,12,r>20?Color.rgb(3,16,25):TEXT,Paint.Align.CENTER);
        }

        void round(Canvas c,float l,float t,float r,float b,float radius,int color) {
            p.setColor(color); c.drawRoundRect(new RectF(l,t,r,b),radius,radius,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(LINE); c.drawRoundRect(new RectF(l,t,r,b),radius,radius,p); p.setStyle(Paint.Style.FILL);
        }

        void text(Canvas c,String value,float x,float y,float size,int color,Paint.Align align) {
            p.setShader(null); p.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.NORMAL)); p.setTextSize(size*1.10f); p.setTextAlign(align); p.setColor(color); c.drawText(value,x,y,p);
        }

        void textBold(Canvas c,String value,float x,float y,float size,int color,Paint.Align align) {
            p.setShader(null); p.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.BOLD)); p.setTextSize(size*1.10f); p.setTextAlign(align); p.setColor(color); c.drawText(value,x,y,p);
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            if (event.getAction()!=MotionEvent.ACTION_UP) return true;
            float x=event.getX()/sx, y=event.getY()/sy;
            if (y>=524) {
                int slot=Math.min(2,(int)(x/(1024f/3f)));
                if(slot==1) activity.startActivity(new Intent(activity,AppGridActivity.class));
                else if(slot==2) activity.startActivity(new Intent(activity,SettingsActivity.class));
                return true;
            }
            if (x>=18&&x<=600&&y>=72&&y<=510) { Launch.navigation(activity); return true; }
            if(x>=614&&x<=1006&&y>=72&&y<=210){Launch.component(activity,"com.reglink.apps.bluetooth","com.reglink.apps.bluetooth.BlueMusicActivity","Bluetooth music");return true;}
            if (x>=630&&x<=990&&y>=333&&y<=494) {
                if(y<414) {
                    if(x<746) Launch.component(activity,"com.reglink.apps.radio","com.reglink.apps.radio.RadioActivity","Radio");
                    else if(x<866) Launch.component(activity,"com.reglink.apps.bluetooth","com.reglink.apps.bluetooth.BluetoothActivity","Bluetooth phone");
                    else Launch.component(activity,"yellow.android.carplay.receiver","yellow.android.carplay.receiver.MainActivity","CarPlay");
                } else {
                    if(x<830) Launch.component(activity,"yellow.android.aasink","com.google.android.projection.sink.ui.MainActivity","Android Auto");
                    else Launch.component(activity,"com.reglink.apps.bluetooth","com.reglink.apps.bluetooth.BlueMusicActivity","Bluetooth music");
                }
                return true;
            }
            if (y>=230&&y<=292&&x>=720&&x<=900) {
                int key = x<780 ? KeyEvent.KEYCODE_MEDIA_PREVIOUS : (x<840 ? KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE : KeyEvent.KEYCODE_MEDIA_NEXT);
                AudioManager am=(AudioManager)activity.getSystemService(Context.AUDIO_SERVICE);
                am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN,key)); am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP,key));
            }
            return true;
        }
    }
}
