package com.js7.hyundai;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;

final class Launch {
    static final String PREFS = "js7_dashboard";
    static final String NAV_KEY = "default_navigation";
    static final String NAV_GOOGLE = "Google Maps";
    static final String NAV_WAZE = "Waze";
    static final String NAV_APPLE = "Apple Maps via CarPlay";

    private Launch() {}

    static String navigationName(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(NAV_KEY, NAV_GOOGLE);
    }

    static void chooseNavigation(final Activity activity, final Runnable changed) {
        final String[] choices = {NAV_GOOGLE, NAV_WAZE, NAV_APPLE};
        final SharedPreferences prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String selected = prefs.getString(NAV_KEY, NAV_GOOGLE);
        int checked = 0;
        for (int i = 0; i < choices.length; i++) if (choices[i].equals(selected)) checked = i;
        final int initial = checked;
        new AlertDialog.Builder(activity)
                .setTitle("Default navigation")
                .setSingleChoiceItems(choices, checked, null)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        AlertDialog d = (AlertDialog) dialog;
                        int selectedIndex = d.getListView().getCheckedItemPosition();
                        if (selectedIndex < 0) selectedIndex = initial;
                        prefs.edit().putString(NAV_KEY, choices[selectedIndex]).apply();
                        Toast.makeText(activity, choices[selectedIndex] + " selected", Toast.LENGTH_SHORT).show();
                        if (changed != null) changed.run();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    static void navigation(Activity activity) {
        String selected = navigationName(activity);
        if (NAV_WAZE.equals(selected)) {
            if (!packageLaunch(activity, "com.waze")) market(activity, "com.waze");
        } else if (NAV_APPLE.equals(selected)) {
            component(activity, "yellow.android.carplay.receiver", "yellow.android.carplay.receiver.MainActivity", "CarPlay receiver");
        } else {
            if (!packageLaunch(activity, "com.google.android.apps.maps")) market(activity, "com.google.android.apps.maps");
        }
    }

    static boolean packageLaunch(Activity activity, String packageName) {
        try {
            Intent intent = activity.getPackageManager().getLaunchIntentForPackage(packageName);
            if (intent == null) return false;
            activity.startActivity(intent);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static void component(Activity activity, String packageName, String className, String label) {
        try {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.setComponent(new ComponentName(packageName, className));
            activity.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(activity, label + " is unavailable", Toast.LENGTH_SHORT).show();
        }
    }

    static void action(Activity activity, String action, String label) {
        try {
            activity.startActivity(new Intent(action));
        } catch (Exception e) {
            Toast.makeText(activity, label + " is unavailable", Toast.LENGTH_SHORT).show();
        }
    }

    static void market(Activity activity, String packageName) {
        try {
            activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + packageName)));
        } catch (Exception e) {
            Toast.makeText(activity, "Install " + packageName + " from Play Store", Toast.LENGTH_LONG).show();
        }
    }

    static void confirmRoot(final Activity activity, String title, String message, final String command) {
        new AlertDialog.Builder(activity)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("Continue", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        runRoot(activity, command);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    static void runRoot(Activity activity, String command) {
        try {
            Runtime.getRuntime().exec(new String[]{"su", "-c", command});
            Toast.makeText(activity, "Command sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(activity, "Root command failed", Toast.LENGTH_LONG).show();
        }
    }

    static String rootOutput(String command) {
        StringBuilder out = new StringBuilder();
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", command});
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) out.append(line).append('\n');
            reader.close();
            p.waitFor();
        } catch (Exception e) {
            out.append("Unable to read: ").append(e.getMessage());
        }
        return out.toString();
    }
}
