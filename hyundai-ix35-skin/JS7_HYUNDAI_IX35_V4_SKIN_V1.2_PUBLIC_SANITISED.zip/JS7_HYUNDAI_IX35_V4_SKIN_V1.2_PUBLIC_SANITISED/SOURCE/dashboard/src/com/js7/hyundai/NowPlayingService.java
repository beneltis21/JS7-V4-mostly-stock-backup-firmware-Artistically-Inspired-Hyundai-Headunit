package com.js7.hyundai;

import android.app.Notification;
import android.graphics.Bitmap;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSession;
import android.os.Bundle;
import android.os.Parcelable;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

public class NowPlayingService extends NotificationListenerService {
    @Override public void onNotificationPosted(StatusBarNotification sbn){
        if(sbn==null||sbn.getNotification()==null)return;
        Notification notification=sbn.getNotification();
        Bundle extras=notification.extras;
        if(extras==null)return;
        try{
            Parcelable tokenValue=extras.getParcelable(Notification.EXTRA_MEDIA_SESSION);
            if(tokenValue instanceof MediaSession.Token){
                MediaController controller=new MediaController(this,(MediaSession.Token)tokenValue);
                MediaMetadata metadata=controller.getMetadata();
                if(metadata!=null){NowPlayingStore.update(metadata,false,sbn.getPackageName());NowPlayingStore.updatePlayback(controller.getPlaybackState(),false);return;}
            }
        }catch(Exception ignored){}
        if(!Notification.CATEGORY_TRANSPORT.equals(notification.category))return;
        String title=text(extras.getCharSequence(Notification.EXTRA_TITLE));
        String artist=text(extras.getCharSequence(Notification.EXTRA_TEXT));
        Bitmap art=bitmap(extras.getParcelable(Notification.EXTRA_LARGE_ICON_BIG));
        if(art==null)art=bitmap(extras.getParcelable(Notification.EXTRA_LARGE_ICON));
        NowPlayingStore.update(title,artist,art,sbn.getPackageName());
    }

    @Override public void onNotificationRemoved(StatusBarNotification sbn){
        if(sbn!=null)NowPlayingStore.clearPackage(sbn.getPackageName());
    }

    private static String text(CharSequence value){return value==null?"":value.toString();}
    private static Bitmap bitmap(Parcelable value){return value instanceof Bitmap?(Bitmap)value:null;}
}
