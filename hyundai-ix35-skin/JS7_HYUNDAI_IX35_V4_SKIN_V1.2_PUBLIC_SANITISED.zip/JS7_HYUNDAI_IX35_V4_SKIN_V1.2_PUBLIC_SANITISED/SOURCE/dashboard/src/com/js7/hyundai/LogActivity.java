package com.js7.hyundai;

import android.app.Activity;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

public class LogActivity extends Activity {
    TextView text;
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);requestWindowFeature(Window.FEATURE_NO_TITLE);getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        text=new TextView(this);text.setBackgroundColor(Color.rgb(6,17,28));text.setTextColor(Color.rgb(244,248,251));text.setTextSize(14.5f);text.setGravity(Gravity.TOP|Gravity.LEFT);text.setPadding(22,18,22,18);text.setText("Reading…");setContentView(text);
        final String mode=getIntent().getStringExtra("mode");
        new AsyncTask<Void,Void,String>(){@Override protected String doInBackground(Void...v){
            if("recovery".equals(mode))return Launch.rootOutput("cat /cache/recovery/last_install 2>/dev/null; echo; tail -n 220 /cache/recovery/last_log 2>/dev/null");
            if("mcu".equals(mode))return Launch.rootOutput("getprop | grep -i -E 'mcu|can|vehicle|reglink'");
            return Launch.rootOutput("getprop; echo; df; echo; cat /proc/meminfo | head -n 12");
        }@Override protected void onPostExecute(String value){text.setText(value.length()==0?"No information returned":value);}}.execute();
    }
}
