package com.js7.hyundai;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.provider.Settings;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

public class SettingsActivity extends Activity {
    SettingsCanvas content;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        content = new SettingsCanvas(this);
        setContentView(content);
    }

    @Override protected void onResume() { super.onResume(); if(content!=null) content.invalidate(); }

    final class SettingsCanvas extends View {
        final int BG=Color.rgb(6,17,28), NAV=Color.rgb(8,23,36), SURFACE=Color.rgb(16,37,56);
        final int LINE=Color.rgb(38,65,88), TEXT=Color.rgb(244,248,251), MUTED=Color.rgb(147,169,186), BLUE=Color.rgb(25,168,245);
        final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        final String[] categories={"Connections","Sound & display","Vehicle","Apps & storage","Advanced","Diagnostics","About"};
        final String[][] titles={
                {"Default navigation","Wi-Fi","Bluetooth","CarPlay","Android Auto","USB / OTG","Now playing access"},
                {"Audio","Display","Language & input","Date & time","Equaliser"},
                {"Vehicle settings","Reverse camera settings","Steering controls","Vehicle information","Power behaviour","MCU settings"},
                {"Installed apps","Storage","Default apps","Permissions"},
                {"Developer options","ADB controls","Local USB update","Recovery reboot","Backup & reset"},
                {"System status","Hardware test","Recovery logs","Build properties"},
                {"JS7 head unit","Android version","Build information","MCU information","Interface build"}
        };
        final String[][] subtitles={
                {"Google Maps, Waze or Apple Maps via CarPlay","Networks and hotspot","Devices, calls and audio","Original receiver","Original projection sink","Host devices and storage","Album art and media metadata"},
                {"Volume and sound controls","Brightness and screen timing","English and keyboard","Automatic or manual","Original RegLink audio processor"},
                {"Original RegLink controls","Original camera configuration","Key learning","Vehicle functions","Sleep and startup","Hardware-specific controls"},
                {"View and manage all applications","Internal and USB storage","Launcher and navigation defaults","Application access controls"},
                {"Visible without tapping build number","USB and Wi-Fi ADB","Original RegLink updater","Confirmation required","Android backup controls"},
                {"Storage, memory and connectivity","Original factory-test application","Read the last recovery result","Device properties and identifiers"},
                {"1024 × 600 RegLink unit","Android 8.1 / API 27","CMDAZX80-U1_R8010_S6.14","Read from device","Hyundai dashboard hardware test v0.5"}
        };
        int category=0;
        float sx=1,sy=1;

        SettingsCanvas(Activity context){super(context); setBackgroundColor(BG);}

        @Override protected void onDraw(Canvas c){
            sx=getWidth()/1024f; sy=getHeight()/600f; c.save(); c.scale(sx,sy);
            p.setColor(BG); c.drawRect(0,0,1024,600,p);
            p.setColor(Color.rgb(7,21,34)); c.drawRect(0,0,1024,58,p);
            text(c,"‹",24,41,35,TEXT,Paint.Align.LEFT); text(c,"Settings",63,38,22,TEXT,Paint.Align.LEFT);
            p.setColor(LINE); c.drawRect(0,57,1024,58,p);
            p.setColor(NAV); c.drawRect(0,58,230,600,p); p.setColor(LINE); c.drawRect(229,58,230,600,p);
            for(int i=0;i<categories.length;i++){
                float top=72+i*62;
                if(i==category) round(c,12,top,218,top+52,10,Color.rgb(10,51,76));
                text(c,categories[i],28,top+33,15,i==category?TEXT:MUTED,Paint.Align.LEFT);
            }
            text(c,categories[category],260,101,24,TEXT,Paint.Align.LEFT);
            drawRows(c);
            c.restore();
        }

        void drawRows(Canvas c){
            String[] t=titles[category], s=subtitles[category];
            for(int i=0;i<t.length;i++){
                int col=i%2,row=i/2; float left=260+col*368,top=124+row*104;
                round(c,left,top,left+350,top+86,12,SURFACE);
                text(c,t[i],left+16,top+35,15,TEXT,Paint.Align.LEFT);
                text(c,s[i],left+16,top+59,11,MUTED,Paint.Align.LEFT);
                text(c,"›",left+329,top+54,25,MUTED,Paint.Align.CENTER);
            }
        }

        void round(Canvas c,float l,float t,float r,float b,float radius,int color){
            p.setColor(color); c.drawRoundRect(new RectF(l,t,r,b),radius,radius,p);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);p.setColor(LINE);c.drawRoundRect(new RectF(l,t,r,b),radius,radius,p);p.setStyle(Paint.Style.FILL);
        }
        void text(Canvas c,String value,float x,float y,float size,int color,Paint.Align align){p.setTextSize(size*1.10f);p.setTextAlign(align);p.setColor(color);p.setTypeface(android.graphics.Typeface.create("sans",0));c.drawText(value,x,y,p);}

        @Override public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP)return true;
            float x=e.getX()/sx,y=e.getY()/sy;
            if(y<58&&x<70){finish();return true;}
            if(x<230&&y>=72){int c=(int)((y-72)/62);if(c>=0&&c<categories.length){category=c;invalidate();}return true;}
            if(x>=260&&y>=124){int col=x<628?0:1;int row=(int)((y-124)/104);int item=row*2+col;if(item>=0&&item<titles[category].length)activate(category,item);}
            return true;
        }

        void activate(int section,int item){
            if(section==0) connection(item);
            else if(section==1) sound(item);
            else if(section==2) vehicle(item);
            else if(section==3) apps(item);
            else if(section==4) advanced(item);
            else if(section==5) diagnostics(item);
            else about(item);
        }

        void connection(int item){
            if(item==0) Launch.chooseNavigation(SettingsActivity.this,new Runnable(){@Override public void run(){invalidate();}});
            else if(item==1) Launch.action(SettingsActivity.this,Settings.ACTION_WIFI_SETTINGS,"Wi-Fi settings");
            else if(item==2) Launch.action(SettingsActivity.this,Settings.ACTION_BLUETOOTH_SETTINGS,"Bluetooth settings");
            else if(item==3) Launch.component(SettingsActivity.this,"yellow.android.carplay.receiver","yellow.android.carplay.receiver.MainActivity","CarPlay");
            else if(item==4) Launch.component(SettingsActivity.this,"yellow.android.aasink","com.google.android.projection.sink.ui.MainActivity","Android Auto");
            else if(item==5) Launch.action(SettingsActivity.this,Settings.ACTION_INTERNAL_STORAGE_SETTINGS,"USB settings");
            else Launch.action(SettingsActivity.this,Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS,"Now playing access");
        }

        void sound(int item){
            if(item==0) Launch.action(SettingsActivity.this,Settings.ACTION_SOUND_SETTINGS,"Sound settings");
            else if(item==1) Launch.action(SettingsActivity.this,Settings.ACTION_DISPLAY_SETTINGS,"Display settings");
            else if(item==2) Launch.action(SettingsActivity.this,Settings.ACTION_LOCALE_SETTINGS,"Language settings");
            else if(item==3) Launch.action(SettingsActivity.this,Settings.ACTION_DATE_SETTINGS,"Date settings");
            else Launch.component(SettingsActivity.this,"com.reglink.equalizer","com.reglink.equalizer.ui.MainActivity","Equaliser");
        }

        void vehicle(int item){
            if(item==2) Launch.component(SettingsActivity.this,"com.reglink.keystudy","com.reglink.keystudy.MainActivity","Steering controls");
            else if(item==3) Launch.component(SettingsActivity.this,"com.reglink.vehicleinfo","com.reglink.vehicleinfo.VehicleFunctionActivity","Vehicle information");
            else Launch.component(SettingsActivity.this,"com.reglink.apps.settings","com.reglink.apps.settings.SettingsListActivity","Vehicle settings");
        }

        void apps(int item){
            if(item==0) Launch.action(SettingsActivity.this,Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS,"Installed applications");
            else if(item==1) Launch.action(SettingsActivity.this,Settings.ACTION_INTERNAL_STORAGE_SETTINGS,"Storage settings");
            else if(item==2) Launch.action(SettingsActivity.this,Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS,"Default applications");
            else Launch.action(SettingsActivity.this,Settings.ACTION_APPLICATION_SETTINGS,"Application permissions");
        }

        void advanced(int item){
            if(item==0) Launch.action(SettingsActivity.this,Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS,"Developer options");
            else if(item==1) adbDialog();
            else if(item==2) Launch.component(SettingsActivity.this,"com.reglink.apps.ota","com.reglink.apps.ota.ForDebugActivity","Local USB update");
            else if(item==3) Launch.confirmRoot(SettingsActivity.this,"Reboot to recovery","The unit will close all applications and reboot into recovery.","sync; reboot recovery");
            else Launch.action(SettingsActivity.this,Settings.ACTION_PRIVACY_SETTINGS,"Backup and reset");
        }

        void adbDialog(){
            final String[] choices={"Enable USB ADB","Enable Wi-Fi ADB on port 5555","Disable Wi-Fi ADB"};
            new AlertDialog.Builder(SettingsActivity.this).setTitle("ADB controls").setItems(choices,new DialogInterface.OnClickListener(){
                @Override public void onClick(DialogInterface d,int which){
                    if(which==0) Launch.confirmRoot(SettingsActivity.this,"Enable USB ADB","Developer access will be enabled.","settings put global adb_enabled 1; setprop persist.sys.usb.config mtp,adb");
                    else if(which==1) Launch.confirmRoot(SettingsActivity.this,"Enable Wi-Fi ADB","ADB will listen on TCP port 5555 after adbd restarts.","settings put global adb_enabled 1; setprop service.adb.tcp.port 5555; stop adbd; start adbd");
                    else Launch.confirmRoot(SettingsActivity.this,"Disable Wi-Fi ADB","Any active Wi-Fi ADB connection will close.","setprop service.adb.tcp.port -1; stop adbd; start adbd");
                }
            }).setNegativeButton("Cancel",null).show();
        }

        void diagnostics(int item){
            if(item==0) Launch.action(SettingsActivity.this,Settings.ACTION_DEVICE_INFO_SETTINGS,"System status");
            else if(item==1) Launch.component(SettingsActivity.this,"com.reglink.apps.factorytest","com.reglink.apps.factorytest.ui.index.IndexActivity","Hardware test");
            else { Intent i=new Intent(SettingsActivity.this,LogActivity.class); i.putExtra("mode",item==2?"recovery":"properties"); startActivity(i); }
        }

        void about(int item){
            if(item==3){Intent i=new Intent(SettingsActivity.this,LogActivity.class);i.putExtra("mode","mcu");startActivity(i);}
            else Toast.makeText(SettingsActivity.this,subtitles[6][item],Toast.LENGTH_LONG).show();
        }
    }
}
