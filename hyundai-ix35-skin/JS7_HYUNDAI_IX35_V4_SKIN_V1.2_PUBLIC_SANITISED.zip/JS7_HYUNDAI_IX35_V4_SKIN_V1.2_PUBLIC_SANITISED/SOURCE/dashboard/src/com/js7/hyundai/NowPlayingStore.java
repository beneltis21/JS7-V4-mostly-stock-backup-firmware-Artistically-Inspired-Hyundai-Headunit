package com.js7.hyundai;

import android.graphics.Bitmap;
import android.media.MediaMetadata;
import android.media.session.PlaybackState;
import android.os.SystemClock;

final class NowPlayingStore {
    private static String title="";
    private static String artist="";
    private static Bitmap art;
    private static boolean bluetoothSource;
    private static String sourcePackage="";
    private static long duration=-1;
    private static int playbackState=PlaybackState.STATE_NONE;
    private static long playbackPosition;
    private static float playbackSpeed=1f;
    private static long playbackUpdateTime;

    private NowPlayingStore(){}

    static synchronized void update(MediaMetadata metadata,boolean bluetooth){
        update(metadata,bluetooth,bluetooth?"bluetooth":"");
    }

    static synchronized void update(MediaMetadata metadata,boolean bluetooth,String packageName){
        if(metadata==null)return;
        String newTitle=first(metadata.getString(MediaMetadata.METADATA_KEY_TITLE),metadata.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE));
        String newArtist=first(metadata.getString(MediaMetadata.METADATA_KEY_ARTIST),metadata.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST),metadata.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE));
        Bitmap newArt=metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
        if(newArt==null)newArt=metadata.getBitmap(MediaMetadata.METADATA_KEY_ART);
        if(newArt==null)newArt=metadata.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
        if(length(newTitle)==0&&length(newArtist)==0&&newArt==null)return;
        title=length(newTitle)==0?"Unknown track":newTitle;
        artist=length(newArtist)==0?"Unknown artist":newArtist;
        art=newArt;
        long newDuration=metadata.getLong(MediaMetadata.METADATA_KEY_DURATION);
        duration=newDuration>0?newDuration:-1;
        bluetoothSource=bluetooth;
        sourcePackage=packageName==null?"":packageName;
    }

    static synchronized void update(String newTitle,String newArtist,Bitmap newArt,String packageName){
        if(length(newTitle)==0&&length(newArtist)==0&&newArt==null)return;
        title=length(newTitle)==0?"Unknown track":newTitle;
        artist=length(newArtist)==0?"Unknown artist":newArtist;
        art=newArt;
        bluetoothSource=false;
        sourcePackage=packageName==null?"":packageName;
    }

    static synchronized void updatePlayback(PlaybackState state,boolean bluetooth){
        if(state==null)return;
        playbackState=state.getState();
        playbackPosition=Math.max(0,state.getPosition());
        playbackSpeed=state.getPlaybackSpeed();
        playbackUpdateTime=state.getLastPositionUpdateTime();
        if(bluetooth)bluetoothSource=true;
    }

    static synchronized void clearPackage(String packageName){
        if(packageName!=null&&packageName.equals(sourcePackage)&&!bluetoothSource)clear();
    }

    static synchronized void clear(){title="";artist="";art=null;bluetoothSource=false;sourcePackage="";duration=-1;playbackState=PlaybackState.STATE_NONE;playbackPosition=0;playbackSpeed=1f;playbackUpdateTime=0;}

    static synchronized Snapshot snapshot(){return new Snapshot(title,artist,art,bluetoothSource,duration,playbackState,playbackPosition,playbackSpeed,playbackUpdateTime);}

    private static String first(String...values){for(String value:values)if(length(value)>0)return value;return "";}
    private static int length(String value){return value==null?0:value.trim().length();}

    static final class Snapshot {
        final String title;
        final String artist;
        final Bitmap art;
        final boolean bluetoothSource;
        final long duration;
        final int playbackState;
        final long position;
        final float speed;
        final long updateTime;
        Snapshot(String title,String artist,Bitmap art,boolean bluetoothSource,long duration,int playbackState,long position,float speed,long updateTime){this.title=title;this.artist=artist;this.art=art;this.bluetoothSource=bluetoothSource;this.duration=duration;this.playbackState=playbackState;this.position=position;this.speed=speed;this.updateTime=updateTime;}
        boolean hasMetadata(){return length(title)>0||length(artist)>0||art!=null;}
        boolean isPlaying(){return playbackState==PlaybackState.STATE_PLAYING;}
        long currentPosition(){
            long value=position;
            if(isPlaying()&&updateTime>0)value+=(long)((SystemClock.elapsedRealtime()-updateTime)*speed);
            if(value<0)value=0;
            if(duration>0&&value>duration)value=duration;
            return value;
        }
        boolean hasTimeline(){return duration>0&&currentPosition()>=0;}
    }
}
