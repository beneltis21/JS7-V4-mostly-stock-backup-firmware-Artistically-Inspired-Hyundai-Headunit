package com.js7.tools;

import android.content.Context;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import java.lang.reflect.Method;

/** Root-only Android 8 app_process helper for the stock WifiService. */
public final class SetWifiIdentity {
    private static Context systemContext() throws Exception {
        Class<?> activityThread = Class.forName("android.app.ActivityThread");
        Method systemMain = activityThread.getDeclaredMethod("systemMain");
        systemMain.setAccessible(true);
        Object thread = systemMain.invoke(null);
        Method getSystemContext = activityThread.getDeclaredMethod("getSystemContext");
        getSystemContext.setAccessible(true);
        return (Context) getSystemContext.invoke(thread);
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 1 || args[0].trim().length() == 0) {
            System.err.println("usage: SetWifiIdentity <hotspot-ssid>|--get");
            System.exit(2);
        }

        String requested = args[0].trim();
        WifiManager wifi = (WifiManager) systemContext().getSystemService(Context.WIFI_SERVICE);
        if (wifi == null) {
            throw new IllegalStateException("WifiManager unavailable");
        }

        Method getConfig = wifi.getClass().getMethod("getWifiApConfiguration");
        WifiConfiguration config = (WifiConfiguration) getConfig.invoke(wifi);
        if (config == null) {
            config = new WifiConfiguration();
        }
        String before = config.SSID;
        if ("--get".equals(requested)) {
            System.out.println("Hotspot: " + before);
            return;
        }
        config.SSID = requested;

        Method setConfig = wifi.getClass().getMethod("setWifiApConfiguration", WifiConfiguration.class);
        Object result = setConfig.invoke(wifi, config);
        if (result instanceof Boolean && !((Boolean) result).booleanValue()) {
            throw new IllegalStateException("WifiService rejected hotspot configuration");
        }

        WifiConfiguration check = (WifiConfiguration) getConfig.invoke(wifi);
        String after = check == null ? null : check.SSID;
        System.out.println("Hotspot before: " + before);
        System.out.println("Hotspot after: " + after);
        if (!requested.equals(after)) {
            throw new IllegalStateException("hotspot verification failed: " + after);
        }
    }
}
