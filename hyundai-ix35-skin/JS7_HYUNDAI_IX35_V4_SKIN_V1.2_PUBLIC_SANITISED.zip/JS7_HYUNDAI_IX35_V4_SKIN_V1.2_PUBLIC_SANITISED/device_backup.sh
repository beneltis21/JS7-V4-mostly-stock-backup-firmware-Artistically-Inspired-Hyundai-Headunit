#!/system/bin/sh
set -eu

STAMP="${1:-manual}"
BACKUP="/sdcard/JS7_BACKUP/${STAMP}"
PRODUCT="$(getprop ro.product.name)"
DEVICE="$(getprop ro.product.device)"
BUILD="$(getprop ro.build.display.id)"
LOGO_PART=/dev/block/platform/mtk-msdc.0/11120000.msdc0/by-name/logo

if [ "$PRODUCT" != "full_k80_bsp" ] || [ "$DEVICE" != "k80_bsp" ] || [ "$BUILD" != "CMDAZX80-U1_R8010_S6.14" ]; then
    echo "ABORT: wrong device: product=$PRODUCT device=$DEVICE build=$BUILD"
    exit 20
fi
[ "$(id -u)" = "0" ] || { echo "ABORT: root ADB is required"; exit 21; }
[ -b "$LOGO_PART" ] || { echo "ABORT: exact JS7 logo partition was not found"; exit 22; }

mkdir -p "$BACKUP"
cp -p /system/build.prop "$BACKUP/build.prop"
cp -p /system/etc/prop.default "$BACKUP/prop.default"
cp -p /system/media/bootanimation.mp4 "$BACKUP/bootanimation.mp4"
if [ -f /system/media/bootlogo.bmp ]; then
    cp -p /system/media/bootlogo.bmp "$BACKUP/bootlogo.bmp"
else
    : > "$BACKUP/bootlogo.bmp.absent"
fi
if [ -f /system/etc/carplay.ini ]; then
    cp -p /system/etc/carplay.ini "$BACKUP/carplay.ini"
else
    : > "$BACKUP/carplay.ini.absent"
fi
if [ -f /system/etc/init/js7_adb_failsafe.rc ]; then
    cp -p /system/etc/init/js7_adb_failsafe.rc "$BACKUP/js7_adb_failsafe.rc"
else
    : > "$BACKUP/js7_adb_failsafe.rc.absent"
fi
if [ -f /data/misc/bluedroid/bt_config.conf ]; then
    cp -p /data/misc/bluedroid/bt_config.conf "$BACKUP/bt_config.conf"
else
    : > "$BACKUP/bt_config.conf.absent"
fi
if [ -f /data/misc/wifi/softap.conf ]; then
    cp -p /data/misc/wifi/softap.conf "$BACKUP/softap.conf"
else
    : > "$BACKUP/softap.conf.absent"
fi
if [ -f /data/local/tmp/js7_hyundai/wifi_identity.jar ]; then
    CLASSPATH=/data/local/tmp/js7_hyundai/wifi_identity.jar app_process /system/bin com.js7.tools.SetWifiIdentity --get > "$BACKUP/hotspot_before.txt" 2>&1 || true
fi
dd if="$LOGO_PART" of="$BACKUP/logo.img" bs=1048576

{
    echo "time_12_24=$(settings get system time_12_24 2>/dev/null || true)"
    echo "bluetooth_name=$(settings get secure bluetooth_name 2>/dev/null || true)"
    echo "global_device_name=$(settings get global device_name 2>/dev/null || true)"
    echo "secure_device_name=$(settings get secure device_name 2>/dev/null || true)"
    echo "timezone=$(getprop persist.sys.timezone)"
    echo "net_hostname=$(getprop net.hostname)"
    echo "persist_net_hostname=$(getprop persist.net.hostname)"
    echo "adb_enabled=$(settings get global adb_enabled 2>/dev/null || true)"
    echo "persist_sys_usb_config=$(getprop persist.sys.usb.config)"
    echo "persist_service_adb_enable=$(getprop persist.service.adb.enable)"
} > "$BACKUP/settings_before.txt"
sync
echo "BACKUP COMPLETE: $BACKUP"
