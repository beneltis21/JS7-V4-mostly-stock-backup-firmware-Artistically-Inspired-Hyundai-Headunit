#!/usr/bin/env bash
set -Eeuo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
ADB_BIN="${ADB_BIN:-adb}"
BACKUP_DIR="${1:-}"
TARGET="${2:-}"

[[ -n "$BACKUP_DIR" && -d "$BACKUP_DIR" ]] || {
  echo "Usage: bash rollback_js7_hyundai.sh JS7_BACKUP_YYYYMMDD_HHMMSS [adb-target]" >&2
  exit 1
}
[[ -f "$BACKUP_DIR/logo.img" ]] || { echo "ERROR: backup has no logo.img" >&2; exit 1; }
[[ "$(wc -c < "$BACKUP_DIR/logo.img" | tr -d ' ')" == "8388608" ]] || { echo "ERROR: logo.img is not exactly 8 MiB" >&2; exit 1; }

if [[ -z "$TARGET" ]]; then
  CONNECTED_DEVICES="$("$ADB_BIN" devices | awk 'NR>1 && $2=="device" {print $1}')"
  DEVICE_COUNT="$(printf '%s\n' "$CONNECTED_DEVICES" | awk 'NF {count++} END {print count+0}')"
  if [[ "$DEVICE_COUNT" == "1" ]]; then
    TARGET="$(printf '%s\n' "$CONNECTED_DEVICES" | awk 'NF {print; exit}')"
  else
    echo "ERROR: connect exactly one ADB device or pass an explicit USB serial/IP:port target" >&2
    exit 1
  fi
fi

if [[ "$TARGET" == *:* ]]; then "$ADB_BIN" connect "$TARGET" >/dev/null 2>&1 || true; fi
"$ADB_BIN" -s "$TARGET" wait-for-device
"$ADB_BIN" -s "$TARGET" root >/dev/null
"$ADB_BIN" -s "$TARGET" wait-for-device
"$ADB_BIN" -s "$TARGET" remount >/dev/null 2>&1 || true
"$ADB_BIN" -s "$TARGET" shell 'mount -o rw,remount /system 2>/dev/null || mount -o rw,remount /dev/block/platform/mtk-msdc.0/11120000.msdc0/by-name/system /system'

REMOTE=/data/local/tmp/js7_rollback
"$ADB_BIN" -s "$TARGET" shell "rm -rf $REMOTE && mkdir -p $REMOTE"
"$ADB_BIN" -s "$TARGET" push "$BACKUP_DIR/." "$REMOTE/" >/dev/null
"$ADB_BIN" -s "$TARGET" push "$HERE/assets/wifi_identity.jar" "$REMOTE/wifi_identity.jar" >/dev/null
"$ADB_BIN" -s "$TARGET" push "$HERE/device_rollback.sh" "$REMOTE/device_rollback.sh" >/dev/null
"$ADB_BIN" -s "$TARGET" shell "/system/bin/sh $REMOTE/device_rollback.sh $REMOTE"
"$ADB_BIN" -s "$TARGET" reboot

echo "Stock boot files, identity settings, clock preference, hotspot and logo partition restored. The unit is rebooting."
