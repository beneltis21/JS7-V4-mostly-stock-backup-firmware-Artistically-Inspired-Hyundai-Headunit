JS7 HYUNDAI IX35 GUARDED ADB SYSTEM UPDATE V1.2 - PUBLIC SANITISED
==================================================================

Exact supported unit only:
  Product: full_k80_bsp
  Device:  k80_bsp
  Build:   CMDAZX80-U1_R8010_S6.14

What this installs
------------------
- Approved Hyundai dashboard interface V0.5, privacy/clock revision V0.5.1.
- Black early boot screen, followed by the approved 1024x600 Hyundai video.
- Hyundai IX35 product, device, Bluetooth and Wi-Fi hotspot identity.
- Hyundai / Hyundai IX35 CarPlay manufacturer and model configuration.
- 12-hour clock and Australia/Sydney timezone.
- Local-only Hyundai code: no INTERNET permission, telemetry, analytics or
  remote update service is added.
- USB ADB permanently enabled in the unit's existing `adb` USB mode, without
  Android computer-key authorization, as explicitly requested by the owner.

What it does not touch
----------------------
- Preloader, LK/LK2, boot, recovery, vendor, NVRAM/NVDATA, MCU, CAN data,
  radio, amplifier configuration, touch configuration or vehicle services.
- Charging and recovery graphics remain stock.
- The stock launcher remains installed as a fallback.

Important identity note
-----------------------
Bluetooth naming is controlled by exact RegLink/MTK properties on this build.
The Wi-Fi AP name is a separately saved Android hotspot SSID; this installer
changes the real saved SSID through
the Android 8 Wi-Fi service. CarPlay exposes manufacturer/model settings, which
this installer sets.
The bundled Android Auto receiver contains some vendor/demo identifiers inside
a platform-signed system APK. This installer sets the system make/model to
Hyundai IX35 without replacing or resigning that hardware app. Verify the name
shown by the phone after the first reboot; the installer does not falsify that
result.

Privacy boundary
----------------
The Hyundai dashboard has no Android INTERNET permission and cannot open an
Internet socket. The Wi-Fi naming helper talks only to the local Android Wi-Fi
service. The package contains no analytics library, telemetry URL or cloud
account. Google Maps, CarPlay, Android Auto and other stock apps remain separate
and may exchange data with their own providers when you choose to use them.
This update does not claim to remove or audit every pre-existing vendor or
Google component in the factory operating system.

USB ADB authentication warning
------------------------------
The captured JS7 hardware state uses persist.sys.usb.config=adb. This update
makes that exact mode persistent and changes ro.adb.secure from 1 to 0. Any
computer physically connected to the USB data port can obtain ADB access with
no trusted-key prompt. The change is intentionally limited to ADB: ro.secure
remains 1 and ro.debuggable remains 0. Wi-Fi ADB remains unchanged on the
unit's existing port 5555. The stock prop.default is backed up for rollback.

An init failsafe reapplies the USB `adb` function at post-fs-data and again when
Android reports boot complete. This is a recovery door for launcher, settings
or Wi-Fi lockouts. It cannot provide ADB while the unit is powered off or if
Android is too damaged to start init/adbd.

Install
-------
1. The unit may stay off and charging while you prepare the files. To install,
   power it normally from stable 12 V. Do not interrupt the boot-logo step.
2. Connect the Mac by ADB. A USB update drive is not used. With Wi-Fi ADB, no
   USB cable is needed; with USB ADB, keep the data cable connected.
3. Open Terminal in this extracted folder.
4. Run:

     bash install_js7_hyundai.sh

The public sanitised installer contains no saved device IP. If exactly one ADB
device is already connected, it selects that device. Otherwise pass the target:

     bash install_js7_hyundai.sh SERIAL_OR_IP:PORT

The installer checks the exact device/build, gains root, backs up stock files
and the complete 8 MiB logo partition to the Mac before changing anything. It
then installs, reboots and verifies model, Bluetooth identity, Wi-Fi hotspot,
12-hour clock, timezone and absence of dashboard INTERNET permission.

If the install completes but Wi-Fi ADB does not reconnect after the reboot, run:

     bash verify_js7_hyundai.sh SERIAL_OR_IP:PORT

Rollback
--------
The install creates JS7_BACKUP_YYYYMMDD_HHMMSS beside this README and also keeps
a copy on the head unit under /sdcard/JS7_BACKUP/. To restore:

     bash rollback_js7_hyundai.sh JS7_BACKUP_YYYYMMDD_HHMMSS
