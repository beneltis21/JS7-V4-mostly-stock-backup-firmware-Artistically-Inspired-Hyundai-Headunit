#!/usr/bin/env bash
set -Eeuo pipefail

ADB_BIN="${ADB_BIN:-adb}"
TARGET="${1:-}"
HERE="$(cd "$(dirname "$0")" && pwd)"

if [[ -z "$TARGET" ]]; then
  CONNECTED_DEVICES="$("$ADB_BIN" devices | awk 'NR>1 && $2=="device" {print $1}')"
  DEVICE_COUNT="$(printf '%s\n' "$CONNECTED_DEVICES" | awk 'NF {count++} END {print count+0}')"
  if [[ "$DEVICE_COUNT" == "1" ]]; then
    TARGET="$(printf '%s\n' "$CONNECTED_DEVICES" | awk 'NF {print; exit}')"
  else
    echo "ERROR: connect exactly one ADB device or pass an explicit USB serial/IP:port target" >&2
    exit 1
  fi
fi

if [[ "$TARGET" == *:* ]]; then "$ADB_BIN" connect "$TARGET" >/dev/null 2>&1 || true; fi
if ! "$ADB_BIN" -s "$TARGET" get-state >/dev/null 2>&1; then
  echo "ERROR: cannot reach $TARGET" >&2
  exit 1
fi
"$ADB_BIN" -s "$TARGET" root >/dev/null 2>&1 || true
"$ADB_BIN" -s "$TARGET" wait-for-device
"$ADB_BIN" -s "$TARGET" push "$HERE/assets/wifi_identity.jar" /data/local/tmp/js7_wifi_identity.jar >/dev/null

PACKAGE_DUMP="$("$ADB_BIN" -s "$TARGET" shell dumpsys package com.js7.hyundai | tr -d '\r')"
if printf '%s\n' "$PACKAGE_DUMP" | grep -q 'android.permission.INTERNET'; then
  PRIVACY_STATUS="FAIL - INTERNET permission present"
else
  PRIVACY_STATUS="PASS - INTERNET permission absent"
fi

echo "Product: $("$ADB_BIN" -s "$TARGET" shell getprop ro.product.name | tr -d '\r')"
echo "Device: $("$ADB_BIN" -s "$TARGET" shell getprop ro.product.device | tr -d '\r')"
echo "Build: $("$ADB_BIN" -s "$TARGET" shell getprop ro.build.display.id | tr -d '\r')"
echo "Model: $("$ADB_BIN" -s "$TARGET" shell getprop ro.product.model | tr -d '\r')"
echo "Bluetooth: $("$ADB_BIN" -s "$TARGET" shell getprop ro.yunovo.bt.name | tr -d '\r')"
echo "Clock: $("$ADB_BIN" -s "$TARGET" shell settings get system time_12_24 | tr -d '\r')"
echo "Timezone: $("$ADB_BIN" -s "$TARGET" shell getprop persist.sys.timezone | tr -d '\r')"
echo "Hotspot: $("$ADB_BIN" -s "$TARGET" shell 'CLASSPATH=/data/local/tmp/js7_wifi_identity.jar app_process /system/bin com.js7.tools.SetWifiIdentity --get' | sed 's/^Hotspot: //' | tr -d '\r')"
echo "Dashboard version: $("$ADB_BIN" -s "$TARGET" shell dumpsys package com.js7.hyundai | sed -n 's/.*versionName=//p' | head -n 1 | tr -d '\r')"
echo "Privacy: $PRIVACY_STATUS"
echo "USB ADB persistent mode: $("$ADB_BIN" -s "$TARGET" shell getprop persist.sys.usb.config | tr -d '\r')"
echo "ADB enabled setting: $("$ADB_BIN" -s "$TARGET" shell settings get global adb_enabled | tr -d '\r')"
echo "ADB authentication flag (expected 0): $("$ADB_BIN" -s "$TARGET" shell getprop ro.adb.secure | tr -d '\r')"
echo "Home: $("$ADB_BIN" -s "$TARGET" shell cmd package resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null | tr -d '\r' || true)"
echo "CarPlay identity configuration:"
"$ADB_BIN" -s "$TARGET" shell cat /system/etc/carplay.ini | tr -d '\r'
