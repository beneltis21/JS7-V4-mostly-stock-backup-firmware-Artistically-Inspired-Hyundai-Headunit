#!/usr/bin/env bash
set -Eeuo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
ADB_BIN="${ADB_BIN:-adb}"
TARGET="${1:-}"

die() {
  echo "ERROR: $*" >&2
  exit 1
}

wait_for_adb() {
  local attempts="$1"
  local i
  for ((i=1; i<=attempts; i++)); do
    if [[ "$TARGET" == *:* ]]; then
      "$ADB_BIN" connect "$TARGET" >/dev/null 2>&1 || true
    fi
    if "$ADB_BIN" -s "$TARGET" get-state >/dev/null 2>&1; then
      return 0
    fi
    sleep 2
  done
  return 1
}

command -v "$ADB_BIN" >/dev/null 2>&1 || die "adb is not installed or not in PATH"

for f in \
  "$HERE/assets/JS7_HYUNDAI_DASHBOARD_V0.5.1_PRIVATE.apk" \
  "$HERE/assets/bootanimation.mp4" \
  "$HERE/assets/black_bootlogo.bmp" \
  "$HERE/assets/carplay.ini" \
  "$HERE/assets/wifi_identity.jar" \
  "$HERE/assets/js7_adb_failsafe.rc" \
  "$HERE/device_backup.sh" \
  "$HERE/device_install.sh"; do
  [[ -f "$f" ]] || die "missing package file: $f"
done

if [[ -z "$TARGET" ]]; then
  CONNECTED_DEVICES="$("$ADB_BIN" devices | awk 'NR>1 && $2=="device" {print $1}')"
  DEVICE_COUNT="$(printf '%s\n' "$CONNECTED_DEVICES" | awk 'NF {count++} END {print count+0}')"
  if [[ "$DEVICE_COUNT" == "1" ]]; then
    TARGET="$(printf '%s\n' "$CONNECTED_DEVICES" | awk 'NF {print; exit}')"
  else
    die "connect exactly one ADB device or pass an explicit USB serial/IP:port target"
  fi
fi

wait_for_adb 30 || die "cannot reach $TARGET; use a connected USB ADB serial or the unit's current Wi-Fi IP"
PRODUCT="$("$ADB_BIN" -s "$TARGET" shell getprop ro.product.name | tr -d '\r')"
DEVICE="$("$ADB_BIN" -s "$TARGET" shell getprop ro.product.device | tr -d '\r')"
BUILD="$("$ADB_BIN" -s "$TARGET" shell getprop ro.build.display.id | tr -d '\r')"

[[ "$PRODUCT" == "full_k80_bsp" ]] || die "wrong product: $PRODUCT"
[[ "$DEVICE" == "k80_bsp" ]] || die "wrong device: $DEVICE"
[[ "$BUILD" == "CMDAZX80-U1_R8010_S6.14" ]] || die "wrong build: $BUILD"

"$ADB_BIN" -s "$TARGET" root >/dev/null
wait_for_adb 15 || die "ADB did not return after requesting root"
UID_NOW="$("$ADB_BIN" -s "$TARGET" shell id -u | tr -d '\r')"
[[ "$UID_NOW" == "0" ]] || die "adbd did not become root"

STAMP="$(date -u +%Y%m%d_%H%M%S)"
STAGE=/data/local/tmp/js7_hyundai
LOCAL_BACKUP="$HERE/JS7_BACKUP_$STAMP"

"$ADB_BIN" -s "$TARGET" shell "rm -rf $STAGE && mkdir -p $STAGE"
"$ADB_BIN" -s "$TARGET" push "$HERE/assets/bootanimation.mp4" "$STAGE/bootanimation.mp4" >/dev/null
"$ADB_BIN" -s "$TARGET" push "$HERE/assets/black_bootlogo.bmp" "$STAGE/black_bootlogo.bmp" >/dev/null
"$ADB_BIN" -s "$TARGET" push "$HERE/assets/carplay.ini" "$STAGE/carplay.ini" >/dev/null
"$ADB_BIN" -s "$TARGET" push "$HERE/assets/wifi_identity.jar" "$STAGE/wifi_identity.jar" >/dev/null
"$ADB_BIN" -s "$TARGET" push "$HERE/assets/js7_adb_failsafe.rc" "$STAGE/js7_adb_failsafe.rc" >/dev/null
"$ADB_BIN" -s "$TARGET" push "$HERE/device_backup.sh" "$STAGE/device_backup.sh" >/dev/null
"$ADB_BIN" -s "$TARGET" push "$HERE/device_install.sh" "$STAGE/device_install.sh" >/dev/null

echo "Creating and downloading the stock backup before any persistent change..."
"$ADB_BIN" -s "$TARGET" shell "/system/bin/sh $STAGE/device_backup.sh $STAMP"
mkdir -p "$LOCAL_BACKUP"
"$ADB_BIN" -s "$TARGET" pull "/sdcard/JS7_BACKUP/$STAMP/." "$LOCAL_BACKUP/" >/dev/null
[[ -s "$LOCAL_BACKUP/build.prop" ]] || die "local backup is missing build.prop"
[[ -s "$LOCAL_BACKUP/prop.default" ]] || die "local backup is missing prop.default"
[[ -s "$LOCAL_BACKUP/bootanimation.mp4" ]] || die "local backup is missing the stock boot video"
[[ -f "$LOCAL_BACKUP/logo.img" ]] || die "local backup is missing the logo partition"
LOGO_BACKUP_BYTES="$(wc -c < "$LOCAL_BACKUP/logo.img" | tr -d ' ')"
[[ "$LOGO_BACKUP_BYTES" == "8388608" ]] || die "local logo backup is not exactly 8 MiB"

echo "Installing the approved Hyundai dashboard without Internet permission..."
"$ADB_BIN" -s "$TARGET" install -r "$HERE/assets/JS7_HYUNDAI_DASHBOARD_V0.5.1_PRIVATE.apk"

"$ADB_BIN" -s "$TARGET" remount >/dev/null 2>&1 || true
"$ADB_BIN" -s "$TARGET" shell 'mount -o rw,remount /system 2>/dev/null || mount -o rw,remount /dev/block/platform/mtk-msdc.0/11120000.msdc0/by-name/system /system'
"$ADB_BIN" -s "$TARGET" shell 'touch /system/.js7_rw_test && rm /system/.js7_rw_test' || die "/system could not be remounted read-write"

echo "Applying the JS7 Hyundai identity, clock and boot configuration..."
"$ADB_BIN" -s "$TARGET" shell "/system/bin/sh $STAGE/device_install.sh $STAMP" | tee "$HERE/INSTALL_LOG_$STAMP.txt"

"$ADB_BIN" -s "$TARGET" shell 'cmd package set-home-activity --user 0 com.js7.hyundai/.HomeActivity' >/dev/null 2>&1 || true
"$ADB_BIN" -s "$TARGET" shell 'cmd package set-home-activity com.js7.hyundai/.HomeActivity --user 0' >/dev/null 2>&1 || true

echo "Rebooting the head unit..."
"$ADB_BIN" -s "$TARGET" reboot

wait_for_adb 90 || die "the unit rebooted but ADB did not return; the install may still be complete, reconnect and run verify_js7_hyundai.sh"
"$ADB_BIN" -s "$TARGET" root >/dev/null 2>&1 || true
wait_for_adb 15 || die "ADB did not return after post-reboot root request"

MODEL="$("$ADB_BIN" -s "$TARGET" shell getprop ro.product.model | tr -d '\r')"
BT_PROP="$("$ADB_BIN" -s "$TARGET" shell getprop ro.yunovo.bt.name | tr -d '\r')"
CLOCK="$("$ADB_BIN" -s "$TARGET" shell settings get system time_12_24 | tr -d '\r')"
TZ="$("$ADB_BIN" -s "$TARGET" shell getprop persist.sys.timezone | tr -d '\r')"
HOME_OUT="$("$ADB_BIN" -s "$TARGET" shell cmd package resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null | tr -d '\r' || true)"
PACKAGE_DUMP="$("$ADB_BIN" -s "$TARGET" shell dumpsys package com.js7.hyundai | tr -d '\r')"
HOTSPOT_OUT="$("$ADB_BIN" -s "$TARGET" shell "CLASSPATH=$STAGE/wifi_identity.jar app_process /system/bin com.js7.tools.SetWifiIdentity --get" | tr -d '\r')"
USB_CONFIG="$("$ADB_BIN" -s "$TARGET" shell getprop persist.sys.usb.config | tr -d '\r')"
ADB_ENABLED="$("$ADB_BIN" -s "$TARGET" shell settings get global adb_enabled | tr -d '\r')"
ADB_SECURE="$("$ADB_BIN" -s "$TARGET" shell getprop ro.adb.secure | tr -d '\r')"

[[ "$MODEL" == "Hyundai IX35" ]] || die "post-reboot model check failed: $MODEL"
[[ "$BT_PROP" == "Hyundai IX35" ]] || die "post-reboot Bluetooth property check failed: $BT_PROP"
[[ "$CLOCK" == "12" ]] || die "post-reboot clock check failed: $CLOCK"
[[ "$TZ" == "Australia/Sydney" ]] || die "post-reboot timezone check failed: $TZ"
[[ "$HOTSPOT_OUT" == "Hotspot: Hyundai IX35" ]] || die "post-reboot hotspot check failed: $HOTSPOT_OUT"
[[ "$USB_CONFIG" == "adb" ]] || die "post-reboot USB ADB configuration check failed: $USB_CONFIG"
[[ "$ADB_ENABLED" == "1" ]] || die "post-reboot ADB enabled-setting check failed: $ADB_ENABLED"
[[ "$ADB_SECURE" == "0" ]] || die "post-reboot no-authorization ADB check failed: ro.adb.secure=$ADB_SECURE"
if printf '%s\n' "$PACKAGE_DUMP" | grep -q 'android.permission.INTERNET'; then
  die "privacy check failed: dashboard requests INTERNET permission"
fi

echo
echo "INSTALL VERIFIED"
echo "Model: $MODEL"
echo "Bluetooth identity: $BT_PROP"
echo "Clock: 12-hour"
echo "Timezone: $TZ"
echo "$HOTSPOT_OUT"
echo "Home: $HOME_OUT"
echo "Dashboard Internet permission: absent"
echo "USB ADB: persistent ($USB_CONFIG), enabled=$ADB_ENABLED, authorization disabled=$ADB_SECURE"
echo "Backup copied to: $LOCAL_BACKUP"
echo "You can now test Bluetooth, CarPlay and Android Auto names from the phone."
