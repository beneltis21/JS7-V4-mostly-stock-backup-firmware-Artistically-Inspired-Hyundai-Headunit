#!/system/bin/sh
set -eu

STAMP="${1:-manual}"
STAGE=/data/local/tmp/js7_hyundai
BACKUP="/sdcard/JS7_BACKUP/${STAMP}"
PRODUCT="$(getprop ro.product.name)"
DEVICE="$(getprop ro.product.device)"
BUILD="$(getprop ro.build.display.id)"

if [ "$PRODUCT" != "full_k80_bsp" ] || [ "$DEVICE" != "k80_bsp" ] || [ "$BUILD" != "CMDAZX80-U1_R8010_S6.14" ]; then
    echo "ABORT: wrong device: product=$PRODUCT device=$DEVICE build=$BUILD"
    exit 20
fi

if [ "$(id -u)" != "0" ]; then
    echo "ABORT: root ADB is required"
    exit 21
fi

LOGO_PART=/dev/block/platform/mtk-msdc.0/11120000.msdc0/by-name/logo
if [ ! -b "$LOGO_PART" ]; then
    echo "ABORT: exact JS7 logo partition was not found"
    exit 22
fi

for f in \
    "$STAGE/bootanimation.mp4" \
    "$STAGE/black_bootlogo.bmp" \
    "$STAGE/carplay.ini" \
    "$STAGE/wifi_identity.jar" \
    "$STAGE/js7_adb_failsafe.rc"; do
    if [ ! -f "$f" ]; then
        echo "ABORT: missing staged file $f"
        exit 23
    fi
done

[ -f "$BACKUP/build.prop" ] && [ -f "$BACKUP/prop.default" ] && [ -f "$BACKUP/bootanimation.mp4" ] && [ -f "$BACKUP/logo.img" ] || {
    echo "ABORT: verified pre-install backup was not found"
    exit 24
}
[ "$(wc -c < "$BACKUP/logo.img" | tr -d ' ')" = "8388608" ] || {
    echo "ABORT: pre-install logo backup is not exactly 8 MiB"
    exit 25
}

set_prop_line() {
    key="$1"
    value="$2"
    tmp="/data/local/tmp/js7_build_prop.$$"
    if grep -q "^${key}=" /system/build.prop; then
        sed "s|^${key}=.*|${key}=${value}|" /system/build.prop > "$tmp"
    else
        cp /system/build.prop "$tmp"
        echo "${key}=${value}" >> "$tmp"
    fi
    cat "$tmp" > /system/build.prop
    rm -f "$tmp"
}

set_prop_line ro.product.manufacturer Hyundai
set_prop_line ro.product.model "Hyundai IX35"
set_prop_line ro.bt.name "Hyundai IX35"
set_prop_line ro.yunovo.bt.name "Hyundai IX35"
set_prop_line net.bt.name "Hyundai IX35"
set_prop_line persist.sys.device_name "Hyundai IX35"
set_prop_line persist.sys.usb.config adb
set_prop_line persist.service.adb.enable 1

set_default_prop_line() {
    key="$1"
    value="$2"
    tmp="/data/local/tmp/js7_default_prop.$$"
    if grep -q "^${key}=" /system/etc/prop.default; then
        sed "s|^${key}=.*|${key}=${value}|" /system/etc/prop.default > "$tmp"
    else
        cp /system/etc/prop.default "$tmp"
        echo "${key}=${value}" >> "$tmp"
    fi
    cat "$tmp" > /system/etc/prop.default
    rm -f "$tmp"
}

set_default_prop_line ro.adb.secure 0

cp "$STAGE/bootanimation.mp4" /system/media/bootanimation.mp4
cp "$STAGE/black_bootlogo.bmp" /system/media/bootlogo.bmp
cp "$STAGE/carplay.ini" /system/etc/carplay.ini
cp "$STAGE/js7_adb_failsafe.rc" /system/etc/init/js7_adb_failsafe.rc
chown 0:0 /system/build.prop /system/etc/prop.default /system/media/bootanimation.mp4 /system/media/bootlogo.bmp /system/etc/carplay.ini /system/etc/init/js7_adb_failsafe.rc
chmod 0644 /system/build.prop /system/media/bootanimation.mp4 /system/media/bootlogo.bmp /system/etc/carplay.ini
chmod 0644 /system/etc/init/js7_adb_failsafe.rc
chmod 0600 /system/etc/prop.default
restorecon /system/build.prop /system/etc/prop.default /system/media/bootanimation.mp4 /system/media/bootlogo.bmp /system/etc/carplay.ini /system/etc/init/js7_adb_failsafe.rc 2>/dev/null || true

settings put system time_12_24 12
settings put global device_name "Hyundai IX35"
settings put secure device_name "Hyundai IX35"
settings put secure bluetooth_name "Hyundai IX35"
settings put global wifi_ap_ssid "Hyundai IX35"
settings put system wifi_ap_ssid "Hyundai IX35"
settings put global adb_enabled 1
setprop persist.sys.timezone Australia/Sydney
setprop net.hostname Hyundai-IX35 || true
setprop persist.net.hostname Hyundai-IX35 || true
setprop net.bt.name "Hyundai IX35" || true
setprop persist.sys.bt.name "Hyundai IX35" || true
setprop persist.bluetooth.name "Hyundai IX35" || true
setprop persist.sys.usb.config adb
setprop persist.service.adb.enable 1
setprop ctl.start adbd || true

if [ -f /data/misc/bluedroid/bt_config.conf ]; then
    if grep -q '^Name = ' /data/misc/bluedroid/bt_config.conf; then
        sed 's/^Name = .*/Name = Hyundai IX35/' /data/misc/bluedroid/bt_config.conf > /data/local/tmp/js7_bt_config.new
    else
        cp /data/misc/bluedroid/bt_config.conf /data/local/tmp/js7_bt_config.new
        echo 'Name = Hyundai IX35' >> /data/local/tmp/js7_bt_config.new
    fi
    cat /data/local/tmp/js7_bt_config.new > /data/misc/bluedroid/bt_config.conf
    rm -f /data/local/tmp/js7_bt_config.new
fi

CLASSPATH="$STAGE/wifi_identity.jar" app_process /system/bin com.js7.tools.SetWifiIdentity "Hyundai IX35"
/system/bin/sh /system/bin/bootlogo_updater.sh "$STAGE/black_bootlogo.bmp"
sync

echo "INSTALL COMPLETE"
echo "Backup: $BACKUP"
echo "Startup: black screen -> Hyundai video -> dashboard"
echo "Identity: Hyundai IX35"
echo "Wi-Fi hotspot: Hyundai IX35"
echo "Clock: 12-hour"
echo "USB ADB: always enabled without host authorization"
